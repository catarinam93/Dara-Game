import { updateValues } from "./config.js";
import { registerUser, joinGame } from "./server.js";
import { main } from "./app.js"

function makeBoard() {
    const info = updateValues();
    const gameBoard = document.getElementById("game-board");
    const boardDimension = document.querySelector('.grid');

    gameBoard.innerHTML = '';
    let row = -1;
    let col = -1;

    if(info[2] === 'dimension1') {
        row = 5;
        col = 6;
    } else if (info[2] === 'dimension2') {
        row = 6;
        col = 5;
    } else {
        row = 6;
        col = 6;
    }

    boardDimension.classList.add(info[2]);

    for (let i = 0; i < row; i++) {
        for (let j = 0; j < col; j++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            cell.dataset.row = i;
            cell.dataset.col = j;

            gameBoard.appendChild(cell);
        }
    }

    const size = {"rows": row, "columns": col};
    return size;
}

document.addEventListener('DOMContentLoaded', () => {    
    // Register a new user
    const submitBtn = document.getElementById("submit-button");

    submitBtn.addEventListener('click', () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        registerUser(username, password);
    });

    var game_cpu = document.querySelector('input[name="game-mode"][value="cpu"]');
    var player = document.querySelectorAll('input[name="start"]');

    // Able/disable difficulty
    function toggleFields() {
        if (game_cpu.checked) {
            player.forEach(function (field) {
                field.disabled = false;
            });
        } else {
            player.forEach(function (field) {
                field.disabled = true;
            });
        }
    }

    toggleFields(); 

    game_cpu.addEventListener("change", toggleFields);

    function checkOptionClicked() {
        var cpuOption = document.querySelector('input[name="game-mode"][value="cpu"]');
        var multiplayerOption = document.querySelector('input[name="game-mode"][value="multiplayer"]');

        if (cpuOption.checked || multiplayerOption.checked) {
            return true;
        } else {
            return false;
        }
    }

    var checkInterval = setInterval(function () {
        if (checkOptionClicked()) {
            toggleFields();
        }
    }, 400);

    // Check if the fields were selected
    function isFieldsFilled() {
        var gameModeElement = document.querySelector('input[name="game-mode"]:checked');
        if (gameModeElement) {
            var gameModeValue = gameModeElement.value;

            if (gameModeValue === "cpu") {
                var firstplayer = document.querySelector('input[name="start"]:checked');
                var boardDim = document.querySelector('input[name="dimension"]:checked');
                return firstplayer && boardDim;
            } else {
                var boardDim = document.querySelector('input[name="dimension"]:checked');
                return boardDim;
            }
        }
        return false;
    }

    //Gets the values available in the configuration screen
    const playButton = document.getElementById("play-button");

    // Able/disable play button
    function updatePlayButtonState() {
        playButton.disabled = !isFieldsFilled();
    }

    updatePlayButtonState();

    // Begins the game
    playButton.addEventListener("click", function (event) {
        if (!isFieldsFilled()) {
            event.preventDefault();
        } else {
            const info = updateValues();
            const size = makeBoard();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            const group = 17;

            if(info[0] === "multiplayer")
                joinGame(group, username, password, size);
            else
                main(info[0], info[1], info[2], size["rows"], size["columns"]);

            //Changes the screen
            const configurations = document.getElementById("configurations");
            const game = document.getElementById("game");
        
            configurations.style.display = "none";
            game.style.display = "block";
        }
    });

    document.querySelectorAll('input[name="game-mode"], input[name="color-player"], input[name="dimension"]').forEach(function (input) {
        input.addEventListener("change", updatePlayButtonState);
    });
});

export{ makeBoard }