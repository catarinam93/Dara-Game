function horizontalCount(squares, lastIndex, currentIndex, cellColor, currentRow, direction) {
    let horizontalCount = 1;

    for (let i = 1; i <= 4; i++) {
        let horiIndex;

        if(direction === "left") horiIndex = currentIndex - i
        else horiIndex = currentIndex + i

        if(horiIndex >= 0 && horiIndex < squares.length) {
            const horiCell = squares[horiIndex]
            const horiRow  = horiCell.dataset.row

            if(
                horiCell.classList.contains(cellColor)
                && horiIndex !== lastIndex
                && horiRow  === currentRow
            ) {
                horizontalCount++;
            } else 
                break;
        } else 
            break;
    }

    return horizontalCount
}

function verticalCount(squares, lastIndex, currentIndex, cellColor, currentCol, columns, direction) {
    let verticalCount = 1;

    for (let i = 1; i <= 4; i++) {
        let vertIndex;

        if(direction === "up") vertIndex = currentIndex - (i * columns)
        else vertIndex = currentIndex + (i * columns)

        if(vertIndex >= 0 && vertIndex < squares.length) {
            const vertCell = squares[vertIndex]
            const vertCol  = vertCell.dataset.col

            if(
                vertCell.classList.contains(cellColor)
                && vertIndex !== lastIndex
                && vertCol  === currentCol
            ) {
                verticalCount++;
            } else 
                break;
        } else 
            break;
    }

    return verticalCount
}

function notLegalMove(squares, lastIndex, currentIndex, player, columns) {
    //Sees the row and column of the current index
    const currentRow = squares[currentIndex].dataset.row;
    const currentCol = squares[currentIndex].dataset.col;
    const cellColor = player === 1 ? 'player-one' : 'player-two';

    const hCount = horizontalCount(squares, lastIndex, currentIndex, cellColor, currentRow, "left") 
                    + horizontalCount(squares, lastIndex, currentIndex, cellColor, currentRow, "right") - 1

    const vCount = verticalCount(squares, lastIndex, currentIndex, cellColor, currentCol, columns, "up")
                    + verticalCount(squares, lastIndex, currentIndex, cellColor, currentCol, columns, "down") - 1

    return (hCount >= 4 || vCount >= 4);

}

function possibleMoves(squares, lastIndex, currentIndex, player, columns) {
    const result = []
    const currentRow =  squares[currentIndex].dataset.row
    const currentCol =  squares[currentIndex].dataset.col

    const left  = currentIndex - 1
    const right = currentIndex + 1 
    const up    = currentIndex - columns
    const down  = currentIndex + columns

    /*
    Three conditions has to be met to be a legal move:
    1 - The index move must not have a piece
    2 - The move has to be a legal one
    3 - The index move can't be the last index move

    We also check if the movement is out of bounds
    */

    if(left >= 0) {
        if(
            squares[left].dataset.row === currentRow
            && !notLegalMove(squares, currentIndex, left, player, columns)
            && !squares[left].classList.contains('has-piece') 
            && lastIndex !== left
        ) result.push(left)
    } 

    if(right < squares.length) {
        if(
            squares[right].dataset.row === currentRow
            && !notLegalMove(squares, currentIndex, right, player, columns)
            && !squares[right].classList.contains('has-piece') 
            && lastIndex !== right
        ) result.push(right)
    } 

    if(up >= 0) {
        if(
            squares[up].dataset.col === currentCol
            && !notLegalMove(squares, currentIndex, up, player, columns)
            && !squares[up].classList.contains('has-piece') 
            && lastIndex !== up
        ) result.push(up)
    }

    if(down < squares.length) {
        if(
            squares[down].dataset.col === currentCol
            && !notLegalMove(squares, currentIndex, down, player, columns)
            && !squares[down].classList.contains('has-piece') 
            && lastIndex !== down
        ) result.push(down)
    }

    return result
}

function canCapture(squares, lastIndex, index, player, columns) {
    //Sees the row and column of the current index
    const currentRow = squares[index].dataset.row;
    const currentCol = squares[index].dataset.col;
    const cellColor = player === 1 ? 'player-one' : 'player-two';

    const hCount = horizontalCount(squares, lastIndex, index, cellColor, currentRow, "left") 
                    + horizontalCount(squares, lastIndex, index, cellColor, currentRow, "right") - 1

    const vCount = verticalCount(squares, lastIndex, index, cellColor, currentCol, columns, "up")
                    + verticalCount(squares, lastIndex, index, cellColor, currentCol, columns, "down") - 1

    return (hCount === 3) || (vCount === 3);
}

function endGame(squares, player, pieces, piecesOnBox){
    const remainingPieces = pieces.length - piecesOnBox

    if(remainingPieces <= 2) return true

    /*
    See all the squares available on the board and verify if there is a legal move
    If a legal move is possible, we return false
    Else, we have a winner (in this case, the other player that isn't the current one) 
    */

    const cellColor = player === 1 ? 'player-one' : 'player-two';
    
    for (let i = 0; i < squares.length; i++){
        if (squares[i].classList.contains(cellColor)){
            const possibleIndexes = possibleMoves(squares, -1, i, player)
            if (possibleIndexes.length > 0){
                return false
            }
        }
    }
    
    return true
}

export { notLegalMove, possibleMoves, canCapture, endGame }; 