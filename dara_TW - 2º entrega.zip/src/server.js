import { startTimer } from "./animation.js";

// Connection with the server
const url = 'http://twserver.alunos.dcc.fc.up.pt:8008/';
// const url = 'http://34.67.217.93:8008/';

// Makes sure that the user only goes to the configurations if he's registered
const configurations = document.getElementById("configurations");
const loginBox = document.getElementById("login-box");

// Messages that will appear to indicate what player is and what phase the game currently is

// Variable imported to leave the game
let gameCode;

//variable to save the board size - used to get the update
var board_size = null;

// Register request
function registerUser(nick, password) {
    let registerUrl = url + "register";

    let registerOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify({
            nick: nick,
            password: password
            })
    };

    fetch(registerUrl, registerOptions)
    .then(response => {
        if(!response.ok) {
            alert("Por favor, tente novamente")
            throw new Error(`Erro na solicitação: ${response.status} - ${response.statusText}`);
        }
        
        return response.json()
    })
    .then(data => {
        loginBox.style.display = "none";
        configurations.style.display = "block";
        console.log(data);
        document.querySelector('#user').innerHTML = nick;
    })
    .catch(console.log);
}


// Join request
function joinGame(group, nick, password, size) {
    let joinUrl = url + "join"; 
  
    // Create the POST request payload
    let payload = {
        group: group,
        nick: nick,
        password: password,
        size: size
    };

    board_size = size;
  
    // Set up the request options
    let requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    };
  
    // Perform the POST request
    fetch(joinUrl, requestOptions)
    .then(response => response.json())
    .then(data => {
        configurations.style.display = "none";
        game.style.display = "block";
        
        console.log(data);
        gameCode = data["game"];

        // Updates the server about the situation of the current player
        update(gameCode, nick);
    })
    .catch(console.log);
}

// Udpate request
function update(game, nick) {
    const updateUrl = url + `update?nick=${encodeURIComponent(nick)}&game=${encodeURIComponent(game)}`;
    const eventSource = new EventSource(updateUrl);

    eventSource.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log(data);

        // Variables necessary make the logic of the game
        var board   = data["board"];
        var phase   = data["phase"];
        var turn    = data["turn"];
        var winner  = data["winner"];

        // If there's a winner, the game ends
        if(winner!==undefined){
            if(winner === nick)
                alert("Your opponent gave up");
            else if(winner === null)
                alert("You were left waitting for too long, try again");
            else
                alert("You lost");

            location.reload();
        } else if(board !== undefined)  {
            const first = document.getElementById('first-text');
            const second = document.getElementById('second-text');

            first.style.display = "block";
            second.style.display = "block";
            startTimer(120);
        }

        document.querySelector('#current-player').innerHTML = turn;
        document.querySelector('#phase').innerHTML = phase;

        makeRound(board);
        makeMove(board, nick, game);

        // Event handler to deal with closed connection
        eventSource.onclose = () => {
            console.log("Closed connection");
            location.reload();
        };

        // Event handler to deal with errors
        eventSource.onerror = function (event) {
            console.error("connection error:", event);
        };

        ranking(17, board_size);
    }
}


// Notify request
function notify(nick, password, game, move) {
    let notifyUrl = url + "notify"; 
  
    // Create the POST request payload
    let payload = {
        nick: nick,
        password: password,
        game: game,
        move: move
    };
  
    // Set up the request options
    let requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    };
  
    // Perform the POST request
    fetch(notifyUrl, requestOptions)
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
    .catch(console.log);    
}


// Leave game request
function leave(nick, password, game) {
    let leaveUrl = url + "leave";

    let requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify({
            nick: nick,
            password: password,
            game: game
        })
    };

    // Perform the POST request
    fetch(leaveUrl, requestOptions)
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
    .catch(console.log);
}


// Show Ranking request
function ranking(group, size) {
    let rankingUrl = url + "ranking";

    // Creates the POST request object
    let requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json' // Indicates that I'm sending a JSON
        },
        body: JSON.stringify({
            group: group,
            size: size
        })
    };

    // Makes the POST Request
    fetch(rankingUrl, requestOptions)
    .then(response => response.json())
    .then(data => {
        const rankingData = data["ranking"]; // Extract relevant data from the response
        let stats_array = [];
        const length = rankingData.length;

        // Cleans the array
        stats_array.length = 0;

        for(let i = 0; i < length; i++) {
            const paragraph = document.createElement('p');

            paragraph.textContent = `Nick: ${rankingData[i]["nick"]}, Games: ${rankingData[i]["games"]}, Victories: ${rankingData[i]["victories"]};`;
            stats_array.push(paragraph.textContent)
        }

        // saves the variable locally 
        save_ranking(stats_array);
    })
    .catch(console.log);
}


// Functions that will create the multiplayer game
function makeRound(board) {
    const rows = board.length;
    const columns = board[0].length;

    // Fill the board with the respective pieces
    for (let i = 0; i < rows; i++) {
        for(let j = 0; j < columns; j++){
            const selector = `.cell[data-row="${i}"][data-col="${j}"]`;
            const cell = document.querySelector(selector);
            cell.classList.add(board[i][j])
        }
    }
}

function makeMove(board, nick, game) {
    const rows = board.length;
    const columns = board[0].length;
    const password = document.getElementById('password').value;

    // Notify about a possible movement of the player
    for (let i = 0; i < rows; i++) {
        for(let j = 0; j < columns; j++){
            const selector = `.cell[data-row="${i}"][data-col="${j}"]`;
            const cell = document.querySelector(selector);
            
            cell.addEventListener('click', () => {
                let move = {"row": i, "column": j};
                notify(nick, password, game, move);
            })
        }
    }
}

// Store the ranking locally with Web Storage
function save_ranking(rankingData) {
    const jsonString = JSON.stringify(rankingData);
    localStorage.setItem('gameRanking', jsonString);
}

function showStatistics() {
    const storage_string = localStorage.getItem('gameRanking');
    const storage = JSON.parse(storage_string);

    const statistics = document.getElementById('statistics');

    // Cleans before adding information
    statistics.innerHTML = '';

    for(let i = 0; i < storage.length; i++) {
        const paragraph = document.createElement('p');

        paragraph.textContent = storage[i];

        statistics.appendChild(paragraph);
    }
}

// // Local tests 
// let group = 17
// let size = {"rows": 6, "columns": 5}

// let player = ["lara", "matheus"]
// let password = ["1234", "palmeiras"]

// let cur_game = 'a7274aee5d4c426a71024f99e890ac8d'
// let move = {"row": 0, "column": 0}

// joinGame(group, player[0], password[0], size);
// joinGame(group, player[1], password[1], size);
// notify(player[1], password[1], cur_game, move)

export { registerUser, joinGame, notify, leave, ranking, gameCode, showStatistics }