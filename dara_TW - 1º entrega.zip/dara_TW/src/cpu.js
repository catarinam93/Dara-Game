import { endGame } from "./rules.js";

function CPUMiniMax(squares, player, depth, pieces, piecesOnBox, columns) {
    const bestMove = minimax(squares, depth, player, -Infinity, Infinity, pieces, piecesOnBox, columns)[1];
    
    return bestMove
  }
  
  function minimax(state, depth, player, alpha, beta, pieces, piecesOnBox, columns) {
    if (depth === 0 || endGame(state, player, pieces, piecesOnBox)) {
        return [evaluateBoard(state, player), null];
    }
  
    const moves = possibleMoves(state, -1, player, columns); // Modify this based on your board size
    let bestMove = -1;
  
    if (player === 1) {
        let maxEval = -Infinity;
        for (const move of moves) {
            const newState = state.slice(); // Create a copy of the current state
            handleMakeMove(newState, -1, move, null);
            const evaluation = minimax(newState, depth - 1, 2, alpha, beta, pieces, piecesOnBox, columns);
            if (maxEval < evaluation[0]) {
                maxEval = evaluation[0];
                bestMove = move;
            }
            alpha = Math.max(alpha, evaluation[0]);
            if (beta <= alpha) {
                break;
            }
        }
        return [maxEval, bestMove];
    } else {
        let minEval = Infinity;
        for (const move of moves) {
            const newState = state.slice(); // Create a copy of the current state
            handleMakeMove(newState, -1, move, null);
            const evaluation = minimax(newState, depth - 1, 1, alpha, beta);
            if (minEval > evaluation[0]) {
                minEval = evaluation[0];
                bestMove = move;
            }
            beta = Math.min(beta, evaluation[0]);
            if (beta <= alpha) {
                break;
            }
        }
        return [minEval, bestMove];
    }
  }
  
  // Heuristic function
  function evaluateBoard(state, player) {
    const playerColor = player === 1 ? 'player-one' : 'player-two';
  
    // Implement your heuristic evaluation here
    let playerPieceCount = 0;
    let opponentPieceCount = 0;
  
    for (const cell of state) {
        if (cell.classList.contains(playerColor)) {
            playerPieceCount++;
        } else if (cell.classList.contains('has-piece') && !cell.classList.contains(playerColor)) {
            opponentPieceCount++;
        }
    }
  
    // Adjust the heuristic evaluation based on your game's strategy
    return playerPieceCount - opponentPieceCount;
  }

  function handleMakeMove(fromIndex, toIndex, color) {
    if(squares[toIndex].classList.contains('possible-move')) {
        removeMoves(squares, currentPlayer, color);
        removePiece(squares, fromIndex, currentPlayer, color, false);
        addPiece(squares, toIndex, currentPlayer, color);
        cleanBoard(squares);

        if (canCapture(squares, -1, toIndex, currentPlayer, columns)) {
            capture = true
        } else {
            switchPlayer();   
        }
        if(!capture) seeMoves = true
    } else {
        removeMoves(squares, currentPlayer, color);
        handleSeeMoves(toIndex, color)
    }
}

  export { CPUMiniMax }