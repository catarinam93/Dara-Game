//Function that fill the pieces with its designated color
function fillPieces(piecesOne, playerOneColor, piecesTwo, playerTwoColor) {
    for (let index = 0; index < piecesOne.length; index++) {
        const piece = piecesOne[index]
        piece.classList.add(playerOneColor)
    }

    for (let index = 0; index < piecesTwo.length; index++) {
        const piece = piecesTwo[index]
        piece.classList.add(playerTwoColor)
    }
}


//Functions related to the possible moves
function removeMoves(squares, currentPlayer, color) {
    for (let i = 0; i < squares.length; i++) {
        if(squares[i].classList.contains('possible-move')) {
            squares[i].classList.remove(currentPlayer === 1 ? 'player-one' : 'player-two')
            squares[i].classList.remove('possible-move')   
            squares[i].classList.remove(color)   
        }
    }
}

function addMoves(squares, i, possibleIndexes, currentPlayer, color) {
    for (let index = 0; index < possibleIndexes.length; index++) {
        const j = possibleIndexes[index]
        squares[j].classList.add(currentPlayer === 1 ? 'player-one' : 'player-two');
        squares[j].classList.add(color);
        squares[j].classList.add('possible-move');
    }
}

//Functions related to the pieces itself
function removePiece(squares, index, player, color, capturePhase) {
    squares[index].classList.remove('has-piece');
    squares[index].classList.remove(color);
    if(capturePhase) squares[index].classList.remove(player === 1 ? 'player-two' : 'player-one');
    else squares[index].classList.remove(player === 1 ? 'player-one' : 'player-two');
}

function addPiece(squares, index, player, color) {
    squares[index].classList.add('has-piece');
    squares[index].classList.add(player === 1 ? 'player-one' : 'player-two');
    squares[index].classList.add(color);
}

//Function that clears all the unnecessary pieces
function cleanBoard(squares) {
    for (let i = 0; i < squares.length; i++) {
        if(!squares[i].classList.contains('has-piece')) {
            if(squares[i].classList.contains('player-one')) {
                squares[i].classList.remove('player-one')
            } else if(squares[i].classList.contains('player-two')) {
                squares[i].classList.remove('player-two')
            }
        }
    }
}

export { fillPieces, removeMoves, addMoves, removePiece, addPiece, cleanBoard }; 