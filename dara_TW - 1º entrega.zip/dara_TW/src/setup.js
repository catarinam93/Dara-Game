import { updateValues } from "./config.js";
import { main } from "./app.js"

function makeBoard() {
    const info = updateValues();
    const gameBoard = document.getElementById("game-board");
    const boardDimension = document.querySelector('.grid');
    gameBoard.innerHTML = '';
    let row = -1;
    let col = -1;

    if(info[4] === 'dimension1') {
        row = 5;
        col = 6;
    } else if (info[4] === 'dimension2') {
        row = 6;
        col = 5;
    } else {
        row = 6;
        col = 6;
    }

    boardDimension.classList.add(info[4]);

    for (let i = 0; i < row; i++) {
        for (let j = 0; j < col; j++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            cell.dataset.row = i;
            cell.dataset.col = j;

            gameBoard.appendChild(cell);
        }
    }

    main(info[0], info[1], info[2], info[3], row, col);
}

//Gets the values available in the configuration screen
const playButton = document.getElementById("play-button");


document.addEventListener('DOMContentLoaded', () => {

    var game_cpu = document.querySelector('input[name="game-mode"][value="cpu"]');
    var levelFields = document.querySelectorAll('input[name="level"]');

    // Able/disable difficulty
    function toggleDifficultyFields() {
        if (game_cpu.checked) {
            levelFields.forEach(function (field) {
                field.disabled = false;
            });
        } else {
            levelFields.forEach(function (field) {
                field.disabled = true;
            });
        }
    }

    toggleDifficultyFields(); 

    game_cpu.addEventListener("change", toggleDifficultyFields);

    function checkOptionClicked() {
        var cpuOption = document.querySelector('input[name="game-mode"][value="cpu"]');
        var multiplayerOption = document.querySelector('input[name="game-mode"][value="multiplayer"]');

        if (cpuOption.checked || multiplayerOption.checked) {
            return true;
        } else {
            return false;
        }
    }

    var checkInterval = setInterval(function () {
        if (checkOptionClicked()) {
            toggleDifficultyFields();
        }
    }, 400);

    // Check if the fields were selected
    function isFieldsFilled() {
        var gameModeElement = document.querySelector('input[name="game-mode"]:checked');
        if (gameModeElement) {
            var gameModeValue = gameModeElement.value;

            if (gameModeValue === "cpu") {
                var levelValue = document.querySelector('input[name="level"]:checked');
                var colorPlayerValue = document.querySelector('input[name="color-player"]:checked');
                var firstplayer = document.querySelector('input[name="start"]:checked');
                var boardDim = document.querySelector('input[name="dimension"]:checked');
                return colorPlayerValue && levelValue && firstplayer && boardDim;
            } else {
                var colorPlayerValue = document.querySelector('input[name="color-player"]:checked');
                var firstplayer = document.querySelector('input[name="start"]:checked');
                var boardDim = document.querySelector('input[name="dimension"]:checked');
                return colorPlayerValue && firstplayer && boardDim;
            }
        }
        return false;
    }

    // Able/disable play button
    function updatePlayButtonState() {
        playButton.disabled = !isFieldsFilled();
    }

    updatePlayButtonState();


    playButton.addEventListener("click", function (event) {
        if (!isFieldsFilled()) {
            event.preventDefault();
        } else {
            const info = updateValues();
            const gameBoard = document.getElementById("game-board");
            const boardDimension = document.querySelector('.grid');

            let row = -1;
            let col = -1;

            if(info[4] === 'dimension1') {
                row = 5;
                col = 6;
            } else if (info[4] === 'dimension2') {
                row = 6;
                col = 5;
            } else {
                row = 6;
                col = 6;
            }

            boardDimension.classList.add(info[4]);

            for (let i = 0; i < row; i++) {
                for (let j = 0; j < col; j++) {
                    const cell = document.createElement("div");
                    cell.classList.add("cell");
                    cell.dataset.row = i;
                    cell.dataset.col = j;

                    gameBoard.appendChild(cell);
                }
            }

            main(info[0], info[1], info[2], info[3], row, col);
        }
    });

    document.querySelectorAll('input[name="game-mode"], input[name="level"], input[name="color-player"], input[name="start"], input[name="dimension"]').forEach(function (input) {
        input.addEventListener("change", updatePlayButtonState);
    });
});

export{ makeBoard }