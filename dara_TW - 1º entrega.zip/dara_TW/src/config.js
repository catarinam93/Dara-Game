function updateValues() {
    var info = []

    // Select the game_settings on the forms
    var gameSettingsForm = document.querySelector(".game_settings");

    var gameModeValue    = gameSettingsForm.querySelector('input[name="game-mode"]:checked').value;
    var colorPlayerValue = gameSettingsForm.querySelector('input[name="color-player"]:checked').value;
    if(gameSettingsForm.querySelector('input[name="level"]:checked'))
        var levelValue       = gameSettingsForm.querySelector('input[name="level"]:checked').value;
    var startValue       = gameSettingsForm.querySelector('input[name="start"]:checked').value;
    var dimensionValue   = gameSettingsForm.querySelector('input[name="dimension"]:checked').value;

    info.push(gameModeValue)
    info.push(colorPlayerValue)
    if (gameModeValue === "cpu") info.push(levelValue)
    else info.push(0)
    info.push(startValue)
    info.push(dimensionValue)

    return info
}

export { updateValues }