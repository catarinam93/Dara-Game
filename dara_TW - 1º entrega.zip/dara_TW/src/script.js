document.addEventListener('DOMContentLoaded', () => {
    const submitBtn = document.getElementById("submit-button");
    const configurations = document.getElementById("configurations");
    const loginBox = document.getElementById("login-box");

    submitBtn.addEventListener('click', () => {
        loginBox.style.display = "none";
        configurations.style.display = "block";
    });

    const playBtn = document.getElementById("play-button");
    const game = document.getElementById("game");

    playBtn.addEventListener('click', () => {
        configurations.style.display = "none";
        game.style.display = "block";
    });
});
