document.addEventListener("DOMContentLoaded", () => { 
    const instructionsButton = document.getElementById("instructions-button");
    const instructions       = document.getElementById("instructions");
    const statisticsButton   = document.getElementById("statistics-button");
    const statisticsMenu     = document.getElementById("statistics");
    const quitButton         = document.getElementById("quit-button");

    instructionsButton.addEventListener("click", () => {
        if (instructions.classList.contains("hidden")) {
            instructions.classList.remove("hidden");
        } else {
            instructions.classList.add("hidden");
        }
    });

    // Global variables for the statitics
    let winner_1 = 0;
    let winner_2 = 0;

    statisticsButton.addEventListener("click", () => {
        if (statisticsMenu.classList.contains("hidden")) {
            statisticsMenu.classList.remove("hidden");
            document.getElementById('player-1-wins').textContent = winner_1;
            document.getElementById('player-2-wins').textContent = winner_2;
        } else {
            statisticsMenu.classList.add("hidden");
        }
    });

    quitButton.addEventListener("click", () => {
        // Restarts the game
        location.reload();
    });
});