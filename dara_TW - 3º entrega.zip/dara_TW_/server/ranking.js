const fs = require('fs').promises;
const path = require('path');

const DATA_FILE = path.join(__dirname, 'groupRankings.json');
let groupRankings = [];

async function loadGroupRankings() {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf-8');
        groupRankings = JSON.parse(data);
    } catch (error) {
        // If the archive does not exists - create an empty one
        if (error.code === 'ENOENT') {
            await fs.writeFile(DATA_FILE, '{}', 'utf-8');
        } else {
            console.error(error);
        }
    }
}


async function handleRankings(nick) {
    await loadGroupRankings();

    try {
        const existingUser = groupRankings.find(user => user.nick === nick);

        if (existingUser) {
            // The user is already registeres - verify the password
            return;
        } else {
            // New user -> register him
            groupRankings.push({ "nick": nick, "victories": 0, "games": 0});
            await saveGroupRankings();
            return;
        }
    } catch (error) {
        console.error(error);
        return { success: false, errorCode: 500, message: 'Internal server error' };
    }
}


async function saveGroupRankings() {
    try {
        await fs.writeFile(DATA_FILE, JSON.stringify(groupRankings), 'utf-8');
    } catch (error) {
        console.error(error);
    }
}

async function getRanking(group, size) {
    await loadGroupRankings();

    try {
        // Creates the ranking of a user
        if (!groupRankings[group]) {
            groupRankings[group] = [];
        }

        // Returns the ranking of the user 
        return groupRankings[group];
    } catch (error) {
        console.error(error);
        return [];
    }
}

function addVictoryToRanking(group, nick) {
    try {
        const user = groupRankings[group].find(user => user.name === nick);
        
        if (user) {
            user.gamesPlayed += 1;
            user.victories += 1;
            saveGroupRankings(); // Saves the alterations after adding a victory
        }
    } catch (error) {
        console.error(error);
    }
}

function addGamePlayedToRanking(group, nick1, nick2) {
    try {
        const user1 = groupRankings[group].find(user => user.name === nick1);
        const user2 = groupRankings[group].find(user => user.name === nick2);

        if (user1 && user2) {
            user1.gamesPlayed += 1;
            user2.gamesPlayed += 1;
            saveGroupRankings(); // Saves the alterations on the archive after adding played game
        }
    } catch (error) {
        console.error(error);
    }
}

module.exports = {
    getRanking,
    handleRankings,
    addVictoryToRanking,
    addGamePlayedToRanking,
};
