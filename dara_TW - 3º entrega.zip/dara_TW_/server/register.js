const fs = require('fs').promises;
const path = require('path');

const DATA_FILE = path.join(__dirname, 'registeredUsers.json');
let registeredUsers = [];

async function loadRegisteredUsers() {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf-8');
        registeredUsers = JSON.parse(data);
    } catch (error) {
        // If the archive does not exists, creat an empty one
        if (error.code === 'ENOENT') {
            await fs.writeFile(DATA_FILE, '[]', 'utf-8');
        } else {
            console.error(error);
        }
    }
}

async function saveRegisteredUsers() {
    try {
        await fs.writeFile(DATA_FILE, JSON.stringify(registeredUsers), 'utf-8');
    } catch (error) {
        console.error(error);
    }
}

async function handleRegistration(nick, password) {
    await loadRegisteredUsers();

    try {
        const existingUser = registeredUsers.find(user => user.nick === nick);

        if (existingUser) {
            // The user is already registeres - verify the password
            if (existingUser.password === password) {
                return { success: true, message: '{}' };
            } else {
                return { success: false, errorCode: 401, message: 'Invalid password' };
            }
        } else {
            // New user -> register him
            registeredUsers.push({ nick, password });
            await saveRegisteredUsers();
            return { success: true, message: '{}' };
        }
    } catch (error) {
        console.error(error);
        return { success: false, errorCode: 500, message: 'Internal server error' };
    }
}

module.exports = {
    handleRegistration,
};
