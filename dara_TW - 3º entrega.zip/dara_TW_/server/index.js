// Basic modules
let PORT = 8117;
let http = require('http');
let url  = require('url');
let fs   = require('fs').promises;

// Internal modules
let register = require('./register.js');
let ranking  = require('./ranking.js');


// Headers for POST and GET methods, respectively
const headers = {
    plain: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Access-Control-Allow-Origin': '*', // Permitir solicitações de qualquer origem
        'Access-Control-Allow-Methods': 'GET, POST',
        'Access-Control-Allow-Headers': 'Content-Type'
    },
    sse: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Access-Control-Allow-Origin': '*',
        'Connection': 'keep-alive'
    }
};


http.createServer(function (request, response) {
    const preq = url.parse(request.url, true);
    const pathname = preq.pathname;
    let answer = {};

    if (request.method === 'OPTIONS') {
        response.writeHead(200, headers.plain);
        response.end();
        return;
    }

    switch(request.method) {
        case 'GET':
            answer = doGet(pathname, request, response);
            break;
        case 'POST':
            answer = doPost(pathname, request);
            break;
        default:
            answer.status = 400;
    }

    if(answer.status === undefined)
        answer.status = 200;
    if(answer.style === undefined)
        answer.style = 'plain';

    response.writeHead(answer.status, headers[answer.style]);
    if(answer.style === 'plain')
        response.end();

}).listen(PORT);


function doGet(pathname, request, response) {
    let answer = {};

    switch(pathname) {
        // ALTERAR DAQUI PARA BAIXO
        case '/update':
            updater.remember(response);
            request.on('close', () =>updater.forget(response));
            setImmediate(() => updater.update(counter.get())); 
            answer.style = 'sse';
            break;
        default:
            answer.status = 400;
        break;
    }

    return answer;
}

async function doPost(pathname, request) {
    let answer = {};
    let body = '';

    switch (pathname) {
        case '/register':
            try {
                body = await getRequestBody(request);
                const data = JSON.parse(body);
                const registrationResult = await register.handleRegistration(data.nick, data.password);
                
                if (registrationResult.success) {
                    // If the registration is succefull, add it to the ranking 
                    ranking.handleRankings(data.nick);
                    
                    answer.status = 200;
                } else {
                    answer.status = 400;
                }
            } catch (error) {
                console.error(error);
                answer.status = 500;
            }
            break;
        case '/ranking':
            try {
                body = await getRequestBody(request);
                const data = JSON.parse(body);

                const rankingData = await ranking.getRanking(data.group, data.size);
                answer.status = 200;
                answer.responseData = { ranking: rankingData };
            } catch (error) {
                console.error(error);
                answer.status = 500;
            }
            break;
        case '/notify':
            try {
                body = await getRequestBody(request);
                const data = JSON.parse(body);

                ranking.addGamePlayedToRanking(data.group, data.nick, data.opponent);

                if (data.winner) {
                    ranking.addVictoryToRanking(data.group, data.winner);
                }
                
                answer.status = 200;
            } catch (error) {
                console.error(error);
                answer.status = 500;
            }
            break;
        default:
            answer.status = 404; // unknown request
            break;
    }

    return answer;
}

async function getRequestBody(request) {
    return new Promise((resolve, reject) => {
        let body = '';
        request.on('data', (chunk) => {
            body += chunk.toString();
        });
        request.on('end', () => {
            resolve(body);
        });
        request.on('error', (error) => {
            reject(error);
        });
    });
}