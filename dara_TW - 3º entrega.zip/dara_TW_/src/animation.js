//Function that fill the pieces with its designated color
function fillPieces(piecesOne, playerOneColor, piecesTwo, playerTwoColor) {
    for (let index = 0; index < piecesOne.length; index++) {
        const piece = piecesOne[index]
        piece.classList.add(playerOneColor)
    }

    for (let index = 0; index < piecesTwo.length; index++) {
        const piece = piecesTwo[index]
        piece.classList.add(playerTwoColor)
    }
}


//Functions related to the possible moves
function removeMoves(squares, currentPlayer, color) {
    for (let i = 0; i < squares.length; i++) {
        if(squares[i].classList.contains('possible-move')) {
            squares[i].classList.remove(currentPlayer === 1 ? 'player-one' : 'player-two')
            squares[i].classList.remove('possible-move')   
            squares[i].classList.remove(color)   
        }
    }
}

function addMoves(squares, i, possibleIndexes, currentPlayer, color) {
    for (let index = 0; index < possibleIndexes.length; index++) {
        const j = possibleIndexes[index]
        squares[j].classList.add(currentPlayer === 1 ? 'player-one' : 'player-two');
        squares[j].classList.add(color);
        squares[j].classList.add('possible-move');
    }
}

//Functions related to the pieces itself
function removePiece(squares, index, player, color, capturePhase) {
    squares[index].classList.remove('has-piece');
    squares[index].classList.remove(color);
    if(capturePhase) squares[index].classList.remove(player === 1 ? 'player-two' : 'player-one');
    else squares[index].classList.remove(player === 1 ? 'player-one' : 'player-two');
}

function addPiece(squares, index, player, color) {
    squares[index].classList.add('has-piece');
    squares[index].classList.add(player === 1 ? 'player-one' : 'player-two');
    squares[index].classList.add(color);
}

//Function that clears all the unnecessary pieces
function cleanBoard(squares) {
    for (let i = 0; i < squares.length; i++) {
        if(!squares[i].classList.contains('has-piece')) {
            if(squares[i].classList.contains('player-one')) {
                squares[i].classList.remove('player-one')
            } else if(squares[i].classList.contains('player-two')) {
                squares[i].classList.remove('player-two')
            }
        }
    }
}

// Animation for the clock

// Starts the timer
function startTimer(duration) {
    var timer = duration, minutes, seconds;
    var currentTimerInterval = setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);
        clock.setTime(minutes, seconds);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (--timer < 0)
            clearInterval(currentTimerInterval);
    }, 1000);
}


  // Restarts the time
function restartTimer() {
    var twoMinutes = 60 * 2,
        display = document.querySelector('#timer'),
        timeoutElement = document.querySelector('.timeout');

    // Cleans the current values for a new game
    if (currentTimerInterval) {
        clearInterval(currentTimerInterval);
    }

    // Starts the timer once again
    startTimer(twoMinutes, display, timeoutElement);

    clock.setTime(2, 0);

}


class Watch {
    static numberSize = 14;
    static largeMarkSize = 10;
    static smallMarkSize = 5;

    constructor(canvasId) {
        this.base = document.getElementById(canvasId);
        this.gc = this.base.getContext('2d');
        this.center = {
            x: this.base.width / 2,
            y: this.base.height / 2
        };
        this.length = Math.min(this.center.x, this.center.y) - Watch.numberSize - Watch.largeMarkSize + 10;

        this.minutes = 0;
        this.seconds = 0;

        this.show();
        setInterval(this.show.bind(this), 1000);
    }

    show() {
        const gc = this.gc;
        this.base.width = this.base.width;

        gc.translate(this.center.x, this.center.y);
        gc.textAlign = "center";
        gc.textBaseline = "middle";
        gc.font = `${Watch.numberSize}pt Arial bold`;

        this.face(gc);
        this.hands(gc);
    }

    face(gc) {
        const numbersToShow = [15, 30, 45, 60];
    
        for (let i = 0; i < numbersToShow.length; i++) {
            const minutes = numbersToShow[i];
            const angle = -minutes * Math.PI / 30 + Math.PI / 2;
    
            gc.save();
            gc.fillStyle = 'pink';
            gc.fillText(minutes, this.length * Math.cos(-angle), this.length * Math.sin(-angle));
    
            gc.rotate(angle);
            gc.moveTo(this.length - 10, 0);
            gc.lineTo(this.length - 10 - Watch.largeMarkSize, 0);
            gc.stroke();
            gc.restore();
        }
    }
    
    
    
    setTime(minutes, seconds) {
        this.minutes = minutes;
        this.seconds = seconds;
        this.time = this.minutes * this.seconds 
        this.show();
    }

    hands(gc) {
        const large = this.length;

        gc.strokeStyle = 'black';
        this.hand(gc, this.seconds, 60, large, 4); // seconds' hand
    }

    hand(gc, value, max, length, width) {
        const angle = (value % max) / max * 2 * Math.PI;

        gc.save();
        gc.rotate(-angle);
        gc.beginPath();
        gc.moveTo(0, 0);
        gc.lineTo(0, -length);
        gc.lineWidth = width;
        gc.stroke();
        gc.restore();
    }
}

var clock = new Watch('clockCanvas');


export { fillPieces, removeMoves, addMoves, removePiece, addPiece, cleanBoard, startTimer, restartTimer }; 