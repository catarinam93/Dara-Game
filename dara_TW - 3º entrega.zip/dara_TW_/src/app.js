import { notLegalMove, possibleMoves, canCapture, endGame } from "./rules.js";
import { fillPieces, addMoves, removeMoves, addPiece, removePiece, cleanBoard, restartTimer } from "./animation.js";
import { makeBoard } from "./setup.js";

function main(gameMode, start, rows, columns) {
    //Determines the basics aspects of the game
    let versusCPU = (gameMode === "cpu")
    let drop = true;

    let currentPlayer = 0
    if(start === "start-black") 
        currentPlayer = 1
    else 
        currentPlayer = 2

    //Variables related to the pieces/grid divs
    const squares = document.querySelectorAll('.grid div');
    const piecesOne = document.querySelectorAll('.black');
    const piecesTwo = document.querySelectorAll('.white');

    //Remaining pieces to be put
    let o = piecesOne.length
    let t = piecesTwo.length

    //Looks what the color of the player one and player two are
    let playerOneColor;
    let playerTwoColor;

    //Verifies which animation is going to be executed and what was the last index clicked
    let seeMoves = true
    let fromIndexOne = -1
    let fromIndexTwo = -1
    let capture = false

    fillPieces(piecesOne, 'black', piecesTwo, 'white')
    playerOneColor = 'black'
    playerTwoColor = 'white'

    document.querySelector('#current-player').innerHTML = currentPlayer;



    for (let i = 0; i < squares.length; i++) {
        squares[i].onclick = () => handlePieceClick(i);
    }


    function handlePieceClick(index) {
        document.querySelector('#message').innerHTML = "";
        //Variable that determines which is the color of the piece
        let color;
        if (currentPlayer === 1) color = playerOneColor;
        else color = playerTwoColor;

        if(versusCPU && (currentPlayer === 2)) {
            return;
        } 
        
        else {
            if(drop) {
                handleDropPhase(index, color);
           } else {
            if(seeMoves) {
                handleSeeMoves(index, color);
    
                } else if(!capture) {
                    if(currentPlayer === 1) handleMakeMove(fromIndexOne, index, color)
                    else handleMakeMove(fromIndexTwo, index, color)
                } else {
                    handleCapture(index, color);
                }
            }
        }

        if(!drop) {
            if(currentPlayer === 1) {
                const oneLose = endGame(squares, currentPlayer, piecesOne, o)
                if(oneLose){ 
                    document.querySelector('#message').innerHTML = "The winner is player Two!";
                    document.querySelector('#first-text').innerHTML = "";
                }
            } else {
                const twoLose = endGame(squares, currentPlayer, piecesTwo, t)
                if(twoLose) {
                    document.querySelector('#message').innerHTML = "The winner is player One!";
                    document.querySelector('#first-text').innerHTML = "";
                }
            }

            checkEndGame();
        }
    }

    // Function to add the CPU's movement after a delay
    function triggerCPUMove() {
        if (versusCPU && currentPlayer === 2) {
            generateCPUMove();
        }
    }

    const cpuMoveInterval = setInterval(triggerCPUMove, 2000); // CPU moves every 2 seconds


    function handleDropPhase(index, color) {
        if (!squares[index].classList.contains('has-piece')) {
            if (notLegalMove(squares, -1, index, currentPlayer, columns)) {
                document.querySelector('#message').innerHTML = "Try Again";
            } else {
                putPiece(index, color);
                switchPlayer();
                if (o === 0 && t === 0) {
                    drop = false;
                }
            }
        }
    }


    function putPiece(index, color) {
        addPiece(squares, index, currentPlayer, color);

        if (currentPlayer === 1) {
            piecesOne[o - 1].classList.remove('black')
            o--
        } else {
            piecesTwo[t - 1].classList.remove('white')
            t--
        }
    }



    function switchPlayer() {
        currentPlayer = currentPlayer === 1 ? 2 : 1;
        document.querySelector('#current-player').innerHTML = currentPlayer;
        restartTimer();
    }

    function handleSeeMoves(index, color) {
        let possibleIndexes = []
        if(currentPlayer === 1) 
            possibleIndexes = possibleMoves(squares, fromIndexOne, index, currentPlayer, columns);
        else 
            possibleIndexes = possibleMoves(squares, fromIndexTwo, index, currentPlayer, columns);

        if(squares[index].classList.contains('has-piece')) {
            if (possibleIndexes.length === 0) {
                document.querySelector('#message').innerHTML = "Impossible to move";
            } //Checks if the player selected the right piece
            else if (
                (squares[index].classList.contains('black') && currentPlayer === 2) 
                || 
                (squares[index].classList.contains('white') && currentPlayer === 1)
                    ) 
            {
                document.querySelector('#message').innerHTML = "Wrong piece";
                return
            } 
            else {
                if(currentPlayer === 1){
                    addMoves(squares, index, possibleIndexes, currentPlayer, color);
                    fromIndexOne = index
                }
                else {
                    addMoves(squares, index, possibleIndexes, currentPlayer, color);
                    fromIndexTwo = index
                }
            }

            seeMoves = false
        }
    }

    function handleMakeMove(fromIndex, toIndex, color) {
        if(squares[toIndex].classList.contains('possible-move')) {
            removeMoves(squares, currentPlayer, color);
            removePiece(squares, fromIndex, currentPlayer, color, false);
            addPiece(squares, toIndex, currentPlayer, color);
            cleanBoard(squares);

            if (canCapture(squares, -1, toIndex, currentPlayer, columns)) {
                capture = true
            } else {
                switchPlayer();   
            }
            if(!capture) seeMoves = true
        } else {
            removeMoves(squares, currentPlayer, color);
            handleSeeMoves(toIndex, color)
        }
    }

    function handleCapture(index, color) {
        if (
            (squares[index].classList.contains('black') && currentPlayer === 1)
            || (squares[index].classList.contains('white') && currentPlayer === 2)
            || (!squares[index].classList.contains('has-piece'))
        ) {
            document.querySelector('#message').innerHTML = "Impossible to capture that piece";
            return
        } else {
            if (currentPlayer === 1) color = playerTwoColor;
            else color = playerOneColor;

            removePiece(squares, index, currentPlayer, color, true)
            if (currentPlayer === 1) {
                piecesTwo[t].classList.add('white')
                piecesTwo[t].classList.add(playerTwoColor)
                t++
            }

            if (currentPlayer === 2) {
                piecesOne[o].classList.add('black')
                piecesOne[o].classList.add(playerOneColor)
                o++
            }

            capture = false
            seeMoves = true
            switchPlayer();
        }
    }


    //Function that deals with the CPU movement
    function generateCPUMove() {
        const color = playerTwoColor;
        const max = rows * columns
        let index = Math.floor(Math.random() * max)

        if(drop) {
            while(squares[index].classList.contains('has-piece') ||
            notLegalMove(squares, -1, index, currentPlayer, columns)) {
                index = Math.floor(Math.random() * max);
            }

            putPiece(index, color);
            switchPlayer();
            if (o === 0 && t === 0) {
                drop = false;
            }
        } else {
            if(!capture) {
                fromIndexTwo = index

                let possibleIndexes = []
                possibleIndexes = possibleMoves(squares, fromIndexTwo, index, currentPlayer, columns);

                while(possibleIndexes.length <= 0 || !squares[index].classList.contains('white')) {
                    index = Math.floor(Math.random() * max);
                    possibleIndexes = possibleMoves(squares, fromIndexTwo, index, currentPlayer, columns);
                }

                const len = possibleIndexes.length
                let indexMove = possibleIndexes[Math.floor(Math.random() * len)]

                removePiece(squares, index, currentPlayer, color, false);
                addPiece(squares, indexMove, currentPlayer, color);
                cleanBoard(squares);

                if (canCapture(squares, -1, indexMove, currentPlayer, columns)) {
                    capture = true;
                } else {
                    switchPlayer();   
                }
            } else {
                while (!squares[index].classList.contains('black')) {
                    index = Math.floor(Math.random() * max);
                }

                removePiece(squares, index, currentPlayer, playerOneColor, true);
                capture = false;
                piecesOne[o].classList.add('black')
                piecesOne[o].classList.add(playerOneColor)
                o++
                switchPlayer();   
            }
        }
    }

    
    const popup = document.getElementById("pop-up");
    const yesButton = document.getElementById("yes-button");
    const noButton = document.getElementById("no-button");

    popup.style.display = "none";
    
    function showGameOverPopup() {

        popup.classList.remove("hidden");

        yesButton.addEventListener('click', () => {
            popup.classList.add("hidden");

            for (let i=0; i<squares.length; i++) {
                const s = squares[i]
                s.className = ""
            }

            for (let i=0; i<11; i++){
                piecesOne[i].classList.add("black")
                piecesTwo[i].classList.add("white")
            }

            makeBoard();
        });

        noButton.addEventListener('click', () => {
            popup.classList.add("hidden");
            location.reload();
        });
    }

    function checkEndGame() {
        if (endGame(squares, currentPlayer, currentPlayer === 1 ? piecesOne : piecesTwo, currentPlayer === 1 ? o : t)
            && !drop) {
            showGameOverPopup();
        }
    }
}

export { main }