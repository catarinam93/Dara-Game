import { showStatistics, gameCode, leave } from "./server.js"; 

document.addEventListener("DOMContentLoaded", () => { 
    const instructionsButton = document.getElementById("instructions-button");
    const instructions       = document.getElementById("instructions");
    const statisticsButton   = document.getElementById("statistics-button");
    const statisticsMenu     = document.getElementById("statistics");
    const quitButton         = document.getElementById("quit-button"); 


    instructionsButton.addEventListener("click", () => {
        if (instructions.classList.contains("hidden")) {
            instructions.classList.remove("hidden");
        } else {
            instructions.classList.add("hidden");
        }
    });

    statisticsButton.addEventListener("click", () => {
        if (statisticsMenu.classList.contains("hidden")) {
            statisticsMenu.classList.remove("hidden");
            showStatistics();
        } else {
            statisticsMenu.classList.add("hidden");
        }
    });


    quitButton.addEventListener("click", () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Restarts the game
        leave(username, password, gameCode);
    });
});
