function updateValues() {
    var info = []

    // Select the game_settings on the forms
    var gameSettingsForm = document.querySelector(".game_settings");

    var gameModeValue    = gameSettingsForm.querySelector('input[name="game-mode"]:checked').value;
    var dimensionValue   = gameSettingsForm.querySelector('input[name="dimension"]:checked').value;

    // Configurations only valid for CPU purposes
    if(gameSettingsForm.querySelector('input[name="start"]:checked'))
        var startValue = gameSettingsForm.querySelector('input[name="start"]:checked').value;

    info.push(gameModeValue)

    if (gameModeValue === "cpu"){
        info.push(startValue)
    } 
    else{
        info.push(null)
    }
    
    info.push(dimensionValue)

    return info
}

export { updateValues }