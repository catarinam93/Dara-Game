import { joinGame, registerUser } from "./server.js";
import { updateValues } from "./config.js";

document.addEventListener('DOMContentLoaded', () => {

    const submitBtn = document.getElementById("submit-button");

    submitBtn.addEventListener('click', () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        registerUser(username, password);
    });


    // Select options to play
    const playBtn = document.getElementById("play-button");

    playBtn.addEventListener('click', () => {
        const info = updateValues();
        
        // If it's a multiplayer, we make a request to the server
        if(info[0] === 'multiplayer') {   
            const group = 17
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            let row = -1;
            let col = -1;

            if(info[3] === 'dimension1') {
                row = 5;
                col = 6;
            } else if (info[3] === 'dimension2') {
                row = 6;
                col = 5;
            } else {
                row = 6;
                col = 6;
            }
            
            const size = {"rows": row, "columns": col}
            joinGame(group, username, password, size);

        // If it's single player, he just goes to the next part
        } else {
            const configurations = document.getElementById("configurations");
            const game = document.getElementById("game");

            configurations.style.display = "none";
            game.style.display = "block";
        }
    });
});